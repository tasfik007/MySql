drop table if exists users;
create table users(
    email varchar(255) not null primary key,
    created_at timestamp default now()
);

insert into users(email)
values('Katie34@yahoo.com'),
      ('Tunde@gmail.com');    
      
select 'Yahoo' as 'Providers',count(*) as 'Total Users' 
from users where email like '%@yahoo.com';

select  case
when email like '%@yahoo.com' then 'Yahoo'
when email like '%@Gmail.com' then 'Gmail'
when email like '%@HotMail.com' then 'HotMail'
else 'Others'
end as providers,

count(*) as totals
from users group by providers;
